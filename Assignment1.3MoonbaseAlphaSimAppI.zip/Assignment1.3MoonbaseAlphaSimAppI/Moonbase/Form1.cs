﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// added extra system to write to a new file
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using System.Net.Sockets;

// For Final Project Assignment I added 2 more rooms for a total of 7 locations

//BTNhallway = in groupBox2 for Personal Nav Device
//  -Hallway for access to secret room - marked by "?" - only accessablie by BTNnorth and BTNwest

//BTNmystery = in groupBox2 for Personal Nav Device - NOT Visible unless in Hallway - marked by "?"

// I added a try-catch block around the initialization of the image array and the area objects to handle
// any exceptions that might occur during this process. Additionally, I included a try-catch block in the
// Display method of the Area class to handle any potential exceptions that might occur while updating the UI elements and position log of user.


namespace Moonbase
{
    public partial class FormMain : Form
    {

        // Nested Area class within the FormMain class. This class will encapsulate properties and methods related to each area.
        public class Area
        {
            // attributes normally go at top of class definition | needs protection, type, and variable name
            // { get; set; } syntax means this property has both a getter and a setter, allowing it to be read from and assigned to
            public string Name { get; set; } // Name of room attribute
            public string Description { get; set; } // description of room attribute 
            public Image BackgroundImage { get; set; } // Background image of room attribute

            // Constructor (takes 3 parameters) to initialize Area properties
            public Area(string name, string description, Image backgroundImage) 
            {
                Name = name;
                Description = description;
                BackgroundImage = backgroundImage;
            }

            // Method to display Area information in the UI / GUI
            public void Display(FormMain form) // takes one parameter, form, which is of type FormMain (the form class)
            {
                // handle any potential exceptions that might occur while updating the UI elements try - catch
                try
                {
                    // reworked code from old UpdateForm Function 
                    form.currentPosition = Name;
                    form.BackgroundImage = BackgroundImage;
                    form.textBox1.Text = Name;
                    form.textBox2.Text = Description;
                    form.LogPosition(Name);
                }
                catch (Exception ex) 
                {
                    MessageBox.Show($"An error occurred while updating the UI: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }

        // global variables 
        private string currentPosition; // keeps track of current position in GUI/form

        // List/Array to store Area objects
        private Area[] areas; // declares an array of Area objects named areas.

        public FormMain()
        {
            InitializeComponent();
            BTNbase.Enabled = false;

            try
            {
                // Initialize arrays to use on Form with existing data
                Image[] backgroundImgs = new Image[] // Array of background images RESPECTIVELY
                {
                Properties.Resources.northMoonBase_MeetingRoom, // comma after each item in array
                Properties.Resources.eastMoonBase_StorageRoom,
                Properties.Resources.southMoonBase_SpaceWalk,
                Properties.Resources.westMoonBase_Cafe,
                Properties.Resources.moonbaseTwink,
                Properties.Resources.hallway_MoonBase,
                Properties.Resources.secretRoom_MoonBase

                }; // needs semi colon after array

                string[] locationNames = new string[] // Array of location Names RESPECTIVELY
                {
                "Meeting Hall", // BTNnorth
                "Storage Room", // BTNeast
                "Spacewalk ~ Near Base", // BTNsouth 
                "Westside Cafe", // BTNwest
                "Base Entrance - Landing Pad", // BTNbase
                "Hallway", // BTNhallway FINAL PROJ ADDITION
                "Secret Room" // BTNmystery
                };

                string[] locationDescriptions = new string[] // Array of location Descriptions RESPECTIVELY
                {
                "Inside, the Meeting Hall is bustling with activity. Pomeranians in their tiny space suits sit attentively at the central command table, which is equipped with state-of-the-art holographic displays and control panels. The walls are adorned with interactive screens showcasing cosmic charts, planetary data, and the latest findings from their explorations. Every detail in the Meeting Hall is designed to inspire collaboration and innovation among the Pomeranian crew, making it the perfect place for brainstorming new ideas and planning their next big adventure in the cosmos.",
                "Welcome to the Storage Room, the meticulously organized hub of our moonbase where all essential supplies and equipment are kept. This room is a treasure trove of technological wonders and provisions, carefully arranged on illuminated shelves and compartments. In the center of the room stands 2 Pomeranian astronauts, ready to embark on their next mission. They are busy inspecting equipment and checking inventory. Their tiny paws and curious expressions add a charming touch to the high-tech environment.",
                "Oops! It looks like our adventurous Pomeranian astronaut took an unexpected detour while heading \"south\" and ended up in the vast expanse of space! Caught in the act of exploring the unknown, our brave little pup floats gracefully in the void, with the backdrop of a magnificent galaxy swirling with vibrant colors. Despite the surprise, our Pomeranian astronaut remains calm and collected, ready to take on the wonders and challenges of deep space.",
                "As you step into the cafe, you're greeted by the aroma of freshly baked goods and the sight of colorful donuts and pastries adorning the shelves. The walls are lined with an array of delectable delights, from fluffy cupcakes to tantalizing tarts, all carefully crafted to bring a smile to your face. In the center of the cafe, three adorable Pomeranian astronauts stand proudly, dressed in their vibrant space suits. Their joyful expressions and wagging tails add an extra touch of cheer to the already lively atmosphere. They serve as the cafe's unofficial mascots, always ready to welcome new guests with a friendly bark.",
                "As you step onto the Base Entrance - Landing Pad, you are immediately struck by a futuristic ambiance. Around the pad, you see several Pomeranians in tiny, colorful space suits. They float and bounce around playfully, some holding Twinkies in their paws while others chase after floating toys. The scene is a delightful blend of high-tech sophistication and playful charm, with small plants and decorations adding a touch of warmth and life to the otherwise metallic environment. As you move closer, the soft hum of machinery and the occasional bark of a Pomeranian create a unique and memorable welcome to this extraordinary lunar outpost.",
                "As you step into the hallway, a sense of mystery envelops you. The dimly lit corridor stretches ahead, with shadows dancing on the walls. There’s an air of intrigue, as if the hallway holds secrets waiting to be uncovered. Pay close attention to your surroundings—things might not be as they seem.",
                "Uh oh, you've stumbled upon the secret toy stash hidden deep within the space hallway. Plush toys of all shapes and colors line the walls, and in the middle of it all, a lone Pomeranian stands shocked, watching you intently. What will you do now? Proceed with caution—who knows what surprises await in this hidden chamber?"
                };

                // Initialize areas array with Area objects
                areas = new Area[locationNames.Length];

                // iterates over the locationNames array (assuming all arrays have the same length), and for each index
                for (int i = 0; i < locationNames.Length; i++)
                {
                    // create a new 'Area" object using elements from locationName, locationDescription, and backgroundImgs
                    areas[i] = new Area(locationNames[i], locationDescriptions[i], backgroundImgs[i]); // created Area object is then stored in the areas array.
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show($"An error occurred while initializing the areas: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        // save location of user to a log file
        private void LogPosition (string position)
        {
            try
            {
                // print the date and time with text "Moved to " + position of user
                string logEntry = $"{DateTime.Now}: Moved to {position}{Environment.NewLine}"; // .NewLine ensures that the log entry ends with a newline, making the log file easier to read.
                                                   // uses System.IO to write to a file / create a file
                File.AppendAllText("user_location_log.txt", logEntry);
            }
            catch (Exception ex) 
            {
                // Handle the exception 
                MessageBox.Show($"An error occurred while logging the position: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BTNnorth_Click(object sender, EventArgs e)
        {
            // calls the Display method of the Area object at index 0 in the areas array.
            areas[0].Display(this); // updates the form (this) with the information of the first area in the list

            //Disable correct button and ensure others are turned on
            BTNnorth.Enabled = false;
            BTNeast.Enabled = true;
            BTNsouth.Enabled = true;
            BTNwest.Enabled = true;
            BTNbase.Enabled = true;
            BTNhallway.Enabled = true;
            // Ensure secret room is not accessible
            BTNmystery.Visible = false;
            BTNmystery.Enabled = false;
        }

        private void BTNeast_Click(object sender, EventArgs e)
        {
            // Update for Storage Room
            areas[1].Display(this);
            //Disable correct button and ensure others are turned on
            BTNnorth.Enabled = true;
            BTNeast.Enabled = false;
            BTNsouth.Enabled = true;
            BTNwest.Enabled = true;
            BTNbase.Enabled = true;
            BTNhallway.Enabled = false;
            // Ensure secret room is not accessible
            BTNmystery.Visible = false;
            BTNmystery.Enabled = false;
        }

        private void BTNsouth_Click(object sender, EventArgs e)
        {
            // Update to Spacewalk
            areas[2].Display(this);
            //Disable correct button and ensure others are turned on
            BTNnorth.Enabled = true;
            BTNeast.Enabled = true;
            BTNsouth.Enabled = false;
            BTNwest.Enabled = true;
            BTNbase.Enabled = true;
            BTNhallway.Enabled = false;
            // Ensure secret room is not accessible
            BTNmystery.Visible = false;
            BTNmystery.Enabled = false;
        }

        private void BTNwest_Click(object sender, EventArgs e)
        {
            // Update to Westside Cafe
            areas[3].Display(this);
            //Disable correct button and ensure others are turned on
            BTNnorth.Enabled = true;
            BTNeast.Enabled = true;
            BTNsouth.Enabled = true;
            BTNwest.Enabled = false;
            BTNbase.Enabled = true;
            BTNhallway.Enabled = true;
            // Ensure secret room is not accessible
            BTNmystery.Visible = false;
            BTNmystery.Enabled = false;
        }

        private void BTNbase_Click(object sender, EventArgs e)
        {
            // Update to Base / Starting point
            areas[4].Display(this);
            //Disable correct button and ensure others are turned on
            BTNnorth.Enabled = true;
            BTNeast.Enabled = true;
            BTNsouth.Enabled = true;
            BTNwest.Enabled = true;
            BTNbase.Enabled = false;
            BTNhallway.Enabled = false;
            // Ensure secret room is not accessible
            BTNmystery.Visible = false;
            BTNmystery.Enabled = false;
        }

        private void BTNhallway_Click(object sender, EventArgs e)
        {
            // Update form to show hallway
            areas[5].Display(this);
            //Disable correct button and ensure others are turned on
            BTNnorth.Enabled = true;
            BTNeast.Enabled = false;
            BTNsouth.Enabled = false;
            BTNwest.Enabled = true;
            BTNbase.Enabled = false;
            BTNhallway.Enabled = false;
            // Add secret room - mystery button to be set to visible once in hallway area
            BTNmystery.Visible = true;
            BTNmystery.Enabled = true;

        }

        private void BTNmystery_Click(object sender, EventArgs e)
        {
            // update form to show mystery room
            areas[6].Display(this);

            BTNnorth.Enabled = false;
            BTNeast.Enabled = false;
            BTNsouth.Enabled = false;
            BTNwest.Enabled = false;
            BTNbase.Enabled = false;
            BTNhallway.Enabled = true;
            BTNmystery.Enabled = false;
        }
    }
}
