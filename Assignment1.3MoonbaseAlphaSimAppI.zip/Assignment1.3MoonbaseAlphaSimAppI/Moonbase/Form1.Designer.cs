﻿namespace Moonbase
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BTNmystery = new System.Windows.Forms.Button();
            this.BTNhallway = new System.Windows.Forms.Button();
            this.BTNbase = new System.Windows.Forms.Button();
            this.BTNwest = new System.Windows.Forms.Button();
            this.BTNsouth = new System.Windows.Forms.Button();
            this.BTNeast = new System.Windows.Forms.Button();
            this.BTNnorth = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Roboto", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.groupBox1.Location = new System.Drawing.Point(31, 309);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(623, 482);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Location Information";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Jokerman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Room Description";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(26, 155);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(567, 300);
            this.textBox2.TabIndex = 2;
            this.textBox2.Text = resources.GetString("textBox2.Text");
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(26, 66);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(567, 31);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Base Entrance - Landing Pad";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Jokerman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Room Name";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.PeachPuff;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox2.Controls.Add(this.BTNmystery);
            this.groupBox2.Controls.Add(this.BTNhallway);
            this.groupBox2.Controls.Add(this.BTNbase);
            this.groupBox2.Controls.Add(this.BTNwest);
            this.groupBox2.Controls.Add(this.BTNsouth);
            this.groupBox2.Controls.Add(this.BTNeast);
            this.groupBox2.Controls.Add(this.BTNnorth);
            this.groupBox2.Font = new System.Drawing.Font("Roboto", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Tomato;
            this.groupBox2.Location = new System.Drawing.Point(1473, 309);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(285, 252);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Personal NAV Device";
            // 
            // BTNmystery
            // 
            this.BTNmystery.Location = new System.Drawing.Point(218, 172);
            this.BTNmystery.Name = "BTNmystery";
            this.BTNmystery.Size = new System.Drawing.Size(43, 44);
            this.BTNmystery.TabIndex = 6;
            this.BTNmystery.Text = "?";
            this.BTNmystery.UseVisualStyleBackColor = true;
            this.BTNmystery.Visible = false;
            this.BTNmystery.Click += new System.EventHandler(this.BTNmystery_Click);
            // 
            // BTNhallway
            // 
            this.BTNhallway.Location = new System.Drawing.Point(6, 39);
            this.BTNhallway.Name = "BTNhallway";
            this.BTNhallway.Size = new System.Drawing.Size(79, 44);
            this.BTNhallway.TabIndex = 5;
            this.BTNhallway.Text = "Hallway";
            this.BTNhallway.UseVisualStyleBackColor = true;
            this.BTNhallway.Click += new System.EventHandler(this.BTNhallway_Click);
            // 
            // BTNbase
            // 
            this.BTNbase.Location = new System.Drawing.Point(104, 108);
            this.BTNbase.Name = "BTNbase";
            this.BTNbase.Size = new System.Drawing.Size(79, 44);
            this.BTNbase.TabIndex = 4;
            this.BTNbase.Text = "Base";
            this.BTNbase.UseVisualStyleBackColor = true;
            this.BTNbase.Click += new System.EventHandler(this.BTNbase_Click);
            // 
            // BTNwest
            // 
            this.BTNwest.Location = new System.Drawing.Point(6, 107);
            this.BTNwest.Name = "BTNwest";
            this.BTNwest.Size = new System.Drawing.Size(79, 44);
            this.BTNwest.TabIndex = 3;
            this.BTNwest.Text = "West";
            this.BTNwest.UseVisualStyleBackColor = true;
            this.BTNwest.Click += new System.EventHandler(this.BTNwest_Click);
            // 
            // BTNsouth
            // 
            this.BTNsouth.Location = new System.Drawing.Point(104, 172);
            this.BTNsouth.Name = "BTNsouth";
            this.BTNsouth.Size = new System.Drawing.Size(79, 44);
            this.BTNsouth.TabIndex = 2;
            this.BTNsouth.Text = "South";
            this.BTNsouth.UseVisualStyleBackColor = true;
            this.BTNsouth.Click += new System.EventHandler(this.BTNsouth_Click);
            // 
            // BTNeast
            // 
            this.BTNeast.Location = new System.Drawing.Point(200, 107);
            this.BTNeast.Name = "BTNeast";
            this.BTNeast.Size = new System.Drawing.Size(79, 44);
            this.BTNeast.TabIndex = 1;
            this.BTNeast.Text = "East";
            this.BTNeast.UseVisualStyleBackColor = true;
            this.BTNeast.Click += new System.EventHandler(this.BTNeast_Click);
            // 
            // BTNnorth
            // 
            this.BTNnorth.Location = new System.Drawing.Point(104, 39);
            this.BTNnorth.Name = "BTNnorth";
            this.BTNnorth.Size = new System.Drawing.Size(79, 44);
            this.BTNnorth.TabIndex = 0;
            this.BTNnorth.Text = "North";
            this.BTNnorth.UseVisualStyleBackColor = true;
            this.BTNnorth.Click += new System.EventHandler(this.BTNnorth_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Moonbase.Properties.Resources.moonbaseTwink;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "Moonbase Twinkie";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BTNeast;
        private System.Windows.Forms.Button BTNnorth;
        private System.Windows.Forms.Button BTNwest;
        private System.Windows.Forms.Button BTNsouth;
        private System.Windows.Forms.Button BTNbase;
        private System.Windows.Forms.Button BTNhallway;
        private System.Windows.Forms.Button BTNmystery;
    }
}

